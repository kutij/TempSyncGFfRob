#ifndef SVECTOR2D_HPP
#define SVECTOR2D_HPP

#include "sPoint2D.hpp"

struct sVector2D {
  float x, y;

  float cross(const sVector2D& v2) const;

  float length() const;

  float length2() const;

  sVector2D(const sPoint2D& p) : x(p.x), y(p.y) {}

  sVector2D(float x, float y) : x(x), y(y) {}

  sVector2D operator+(const sVector2D& v2) const;

  sVector2D operator-(const sVector2D& v2) const;

  sVector2D operator*(float c) const;

  float operator*(const sVector2D& v2) const;

  sVector2D operator/(float c) const;
};

sVector2D operator-(const sPoint2D& p1, const sPoint2D& p2);

sPoint2D affine_combination(const sPoint2D& p1, const sPoint2D& p2, float s);

#endif
