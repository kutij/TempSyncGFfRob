#include "DistanceChecker.hpp"
#include "polyline_distance.hpp"

bool arePolylinesCloserThanThreshold(std::vector<sPoint2D>& polyline1, std::vector<sPoint2D>& polyline2) {
  // Initialize checker (only copies the input)
  DistanceChecker checker(polyline1, polyline2, 1.5);
  // Perform check and return
  return checker.Check();
}
