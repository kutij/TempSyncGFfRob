#include "DistanceChecker.hpp"
#include <stdexcept>
#include "sPoint2D.hpp"

sPoint2D::sPoint2D(float xValue, float yValue)
{
	x = xValue;
	y = yValue;
}
