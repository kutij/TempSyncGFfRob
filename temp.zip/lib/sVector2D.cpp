#include "sVector2D.hpp"
#include <stdexcept>
#include <cmath>

sVector2D operator-(const sPoint2D& p1, const sPoint2D& p2) {
  return sVector2D(p1.x - p2.x, p1.y - p2.y);
}

sPoint2D affine_combination(const sPoint2D& p1, const sPoint2D& p2, float t) {
  return { p1.x * (1 - t) + p2.x * t, p1.y * (1 - t) + p2.y * t };
}

float sVector2D::cross(const sVector2D& v2) const {
  return x * v2.y - y * v2.x;
}

float sVector2D::length() const {
  return sqrtf(x * x + y * y);
}

float sVector2D::length2() const {
  return x * x + y * y;
}

sVector2D sVector2D::operator+(const sVector2D& v2) const {
  return { x + v2.x,y + v2.y };
}

sVector2D sVector2D::operator-(const sVector2D& v2) const {
  return { x + v2.x,y + v2.y };
}

sVector2D sVector2D::operator*(float c) const {
  return { x * c,y * c };
}

float sVector2D::operator*(const sVector2D& v2) const {
  return x * v2.x + y * v2.y;
}

sVector2D sVector2D::operator/(float c) const {
  return { x / c,y / c };
}