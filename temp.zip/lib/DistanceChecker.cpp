#include "DistanceChecker.hpp"
#include <stdexcept>

DistanceChecker::DistanceChecker(const std::vector<sPoint2D>& polyline1, const std::vector<sPoint2D>& polyline2, float threshold) : l1(polyline1), l2(polyline2),
threshold(threshold) {}

bool DistanceChecker::CheckNaive() {
  // Error if one of the polylines are empty
  if (l1.size() == 0 || l2.size() == 0)
	throw std::runtime_error("empty polyline!");
  float s, t;
  // If there are two polylines
  if (l1.size() > 1 && l2.size() > 1) {
	for (int i1 = 0; i1 < l1.size() - 1; i1++)
	  for (int i2 = 0; i2 < l2.size() - 1; i2++)
		if (_getDistance(l1[i1], l1[i1 + 1], l2[i2], l2[i2 + 1], s, t) < threshold)
		  return true;
	return false;
  }
  // If there are a polyline and a point
  if (l1.size() > 1) {
	for (int i1 = 0; i1 < l1.size() - 1; i1++)
	  if (_getDistance(l1[i1], l1[i1 + 1], l2[0], l2[0], s, t) < threshold)
		return true;
	return false;
  }
  if (l2.size() > 1) {
	for (int i2 = 0; i2 < l2.size() - 1; i2++)
	  if (_getDistance(l1[0], l1[0], l2[i2], l2[i2 + 1], s, t) < threshold)
		return true;
	return false;
  }
  // if there are only two points
  return (l1[0] - l2[0]).length() < threshold;
}

bool DistanceChecker::Check() {
  // Error if one of the polylines are empty
  if (l1.size() == 0 || l2.size() == 0)
	throw std::runtime_error("empty polyline!");
  float s, t;
  // If there are two polylines
  if (l1.size() > 1 && l2.size() > 1) {
	for (int i1 = 0; i1 < l1.size()-1; i1++)
	  for (int i2 = 0; i2 < l2.size()-1; i2++)
		if (_aabbTest(l1[i1], l1[i1 + 1], l2[i2], l2[i2 + 1], threshold))
		  if (_getDistance(l1[i1], l1[i1 + 1], l2[i2], l2[i2 + 1], s, t) < threshold)
			return true;
	return false;
  }
  // If there are a polyline and a point
  if (l1.size() > 1) {
	for (int i1 = 0; i1 < l1.size()-1; i1++)
	  if (_aabbTest(l1[i1], l1[i1 + 1], l2[0], l2[0], threshold))
		if (_getDistance(l1[i1], l1[i1 + 1], l2[0], l2[0], s, t) < threshold)
		  return true;
	return false;
  }
  if (l2.size() > 1) {
	  for (int i2 = 0; i2 < l2.size()-1; i2++)
		if (_aabbTest(l1[0], l1[0], l2[i2], l2[i2 + 1], threshold))
		  if (_getDistance(l1[0], l1[0], l2[i2], l2[i2 + 1], s, t) < threshold)
			return true;
	return false;
  }
  // if there are only two points
  return (l1[0] - l2[0]).length() < threshold;
}

inline float DistanceChecker::_getDistance(const sPoint2D& p0, const sPoint2D& p1,
  const sPoint2D& q0, const sPoint2D& q1, float& s, float& t) {
  // Compute necessary coefficients
  double a = (p1 - p0).length2();
  double c = (q1 - q0).length2();
  double b = (p1 - p0) * (q1 - q0);
  double d = (p1 - p0) * (p0 - q0);
  double e = (q1 - q0) * (p0 - q0);
  double f = (p0 - q0).length2();

  // Find closest points  described as p_closest=(1-s)p0+s*p1, q_closest=(1-t)q0+t*q1
  double det = a * c - b * b;
  if (det > 0) { // non parallel segments
	double bte = b * e;
	double ctd = c * d;
	if (bte <= ctd) { // s <= 0
	  if (e < 0) { // t <= 0 (region 6)
		s = (-d >= a ? 1 : (-d > 0 ? -d / a : 0));
		t = 0;
	  }
	  else if (e < c) {  // 0 < t < 1 (region 5)
		s = 0;
		t = e / c;
	  }
	  else { // t >= 1 (region 4)
		s = (b - d >= a ? 1 : (b - d > 0 ? (b - d) / a : 0));
		t = 1;
	  }
	}
	else { // s>0
	  s = bte - ctd;
	  if (s > det) { // s>=1
		if (b + e <= 0) { //t<=0 (region 8)
		  s = (-d <= 0 ? 0 : (-d < a ? -d / a : 1));
		  t = 0;
		}
		else if (b + e < c) { // 0 < t < 1 (region 1)
		  s = 1;
		  t = (b + e) / c;
		}
		else { // t>=1 (region 2)
		  s = (b - d <= 0 ? 0 : (b - d < a ? (b - d) / a : 1));
		  t = 1;
		}
	  }
	  else { // 0<s<1
		double ate = a * e, btd = b * d;
		if (ate <= btd) { // t<=0 (region 7)
		  s = (-d <= 0 ? 0 : (-d >= a ? 1 : -d / a));
		  t = 0;
		}
		else { //t>0
		  t = ate - btd;
		  if (t >= det) {
			s = (b - d <= 0 ? 0 : (b - d >= a ? 1 : (b - d) / a));
			t = 1;
		  }
		  else { // 0 < t < 1
			s /= det;
			t /= det;
#ifdef DEBUG
			printf("s=%f, t=%f, d=0\n", s, t);
#endif
			return 0;
		  }
		}
	  }
	}
  }
  else {
	if (e <= 0) {
	  s = (-d <= 0 ? 0 : (-d >= a ? 1 : -d / a));
	  t = 0;
	}
	else if (e >= c) {
	  s = (b - d <= 0 ? 0 : (b - d >= a ? 1 : (b - d) / a));
	  t = 1;
	}
	else {
	  s = 0; t = e / c;
	}
  }
  double distance2 = a * s * s - 2 * b * s * t + c * t * t + 2 * d * s - 2 * e * t + f;
  if (distance2 < 0)
	return 0;
  double distance = sqrtf(distance2);
#ifdef DEBUG
  printf("s=%f, t=%f, d=%f\n", s, t, distance);
#endif
  return distance;
}

float max(float a, float b) {
  return a > b ? a : b;
}

float min(float a, float b) {
  return a < b ? a : b;
}

bool DistanceChecker::_aabbTest(const sPoint2D& p0, const sPoint2D& p1, const sPoint2D& q0, const sPoint2D& q1, float threshold) {
  if (min(p0.x, p1.x) - threshold < max(q0.x, q1.x) && min(q0.x, q1.x) < max(p0.x, p1.x) + threshold)
	if (min(p0.y, p1.y) - threshold < max(q0.y, q1.y) && min(q0.y, q1.y) < max(p0.y, p1.y) + threshold)
	  return true;
  return false;
}
