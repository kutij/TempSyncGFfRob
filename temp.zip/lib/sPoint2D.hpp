#ifndef SPOINT2D_HPP
#define SPOINT2D_HPP

struct sPoint2D {
  sPoint2D(float xValue, float yValue);
  float x;
  float y;
};

#endif
