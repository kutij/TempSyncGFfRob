#ifndef DISTANCE_CHECKER_HPP
#define DISTANCE_CHECKER_HPP

#include "sPoint2D.hpp"
#include "sVector2D.hpp"
#include <vector>

class DistanceChecker {
  const std::vector<sPoint2D> l1, l2;
  const float threshold;
public:
  DistanceChecker(const std::vector<sPoint2D>& polyline1,
	const std::vector<sPoint2D>& polyline2, float threshold);

  bool CheckNaive();

  bool Check();

  static float _getDistance(const sPoint2D& p0, const sPoint2D& p1,
	const sPoint2D& q0, const sPoint2D& q1, float& s, float& t);

  static bool _aabbTest(const sPoint2D& p0, const sPoint2D& p1,
	const sPoint2D& q0, const sPoint2D& q1, float threshold);
};

#endif
