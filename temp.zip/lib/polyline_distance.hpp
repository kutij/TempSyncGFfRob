#ifndef DISTANCE_CHECKER_HPP
#define DISTANCE_CHECKER_HPP

#include "sPoint2D.hpp"
#include <vector>

/// <summary>
/// The function tests if the distance of the given polylines are smaller than 1.5.
/// 
/// It uses aabb prefiltering and performs the distance computation only for the
/// intersecting aabb boxes (of tolerance 1.5) although this method still has omplexity of O((N-1)*(M-1))
/// where N and M are the number of points of the polylines.
/// 
/// The distance computation method is the first method of
/// https://www.geometrictools.com/Documentation/DistanceLine3Line3.pdf
/// 
/// The method throws an std::runtime_error if any of the std::vectors is empty.
/// </summary>
/// <param name="polyline1"> std::vector of points of the first polyline </param>
/// <param name="polyline2"> std::vector of points of the second polyline </param>
/// <returns> if the polylines are closer than 1.5 </returns>
bool arePolylinesCloserThanThreshold(std::vector<sPoint2D>& polyline1, std::vector<sPoint2D>& polyline2);

#endif
