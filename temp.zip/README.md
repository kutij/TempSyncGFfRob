# Algorithmic Task by József Kuti

The project can be configurated and installed from its source folder via CMake as

- mkdir build

- cd build

- cmake ..

Then the project can be built and installed in debug/release/etc. configurations. The functionality of the generated package can be used via

- find_package(ContinentalTaskKJ)
- ...
- target\_link\_libraries(new_project ContinentalTaskKJ::lib)


To access to the built-in tests, the following settings can be used

- cmake -DBUILD_TESTS="ON"

or setting it in the interface of cmake-gui.

In its current state the project fetches and builds the googletest projects in the solution because its original cmake version does not support installing more configurations into its cmake package. (So build would be available only in one configuration.)

The implementation is based on analytic distance computation of line segments. Two methods are implemented based on this:

- the naive check of each segments with the segments of the other polyline (until a distance < 1.5 is found)

- a bit more sophisticated search by applying an aabb-based prefiltering (in best case decreases the computational cost to ~20%).

The implemented test methods test the method that computes the distance of line segments (if the distance of the given points is the computed one and if that is a minima so the distance). The other method  checks if the naive way and the aabb-based return the same result. The test uses cornercases and random examples. The computation has a small numeric flaw, the tester tries to overcome them via absolute and relative numeric thresholds (5e-5). To decrease it, the algorithm uses double format instead of float inside.

The analytic complexity of the method is O(n*m) in worst case, where n and m are the number of segments of the polylines. It is alleviated by exiting if a small enough distance is found and could be further improved by building aabb tree to avoid the check of all possible pairs.

One of the tests checks the computational relaxation of the aabb prefiltering and that fails in DEBUG onfiguration.
