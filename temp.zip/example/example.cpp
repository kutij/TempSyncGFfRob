#include "polyline_distance.hpp"
#include <iostream>

int main(int argc, char *argv[]) {
  std::vector<sPoint2D> polyline1{ sPoint2D(2.0F, 3.0F), sPoint2D(3.0F, 4.0F), sPoint2D(2.0F, 6.0F) };
  std::vector<sPoint2D> polyline2{ sPoint2D(5.0F, 6.0F), sPoint2D(5.0F, 4.0F), sPoint2D(7.0F, 4.0F), sPoint2D(7.0F, 2.0F) };

  if (arePolylinesCloserThanThreshold(polyline1, polyline2))
	std::cout << "They are closer than 1.5" << std::endl;
  else
	std::cout << "They are farther than 1.5" << std::endl;
  return 0;
}